var a = 50;
var b = 100;
console.log("value of a is ",a);
console.log("value of b is ",b);

if(a>b){
    console.log("a is greater than b");
}else if(a<b){
    console.log("a is less than b");
}else{
    console.log("a could be equal to b");
}