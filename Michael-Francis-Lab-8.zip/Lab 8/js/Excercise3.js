var framework ='react';
console.log("The framework is react");
switch(framework){
    case 'react':console.log("javascript");break;
    case 'angular':console.log("typescript");break;
}